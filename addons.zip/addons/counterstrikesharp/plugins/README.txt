Place plugins in this folder. Each plugin should be in its own subfolder, e.g.

TestPlugin/TestPlugin.dll
AnotherPlugin/AnotherPlugin.dll